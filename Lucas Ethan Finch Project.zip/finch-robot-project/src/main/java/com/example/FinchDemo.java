package com.example;

import com.birdbrain.Finch;

public class FinchDemo {
    public static void main(String[] args) {
        Finch myFinch = new Finch();

myFinch.setMove("F", 5, 50);
        myFinch.setTurn("R", 90, 50);
        myFinch.setMove("F", 5, 50);
        myFinch.setTurn("R", 90, 50);
        myFinch.setMove("F", 5, 50);
        myFinch.setTurn("R", 90, 50);
        myFinch.setMove("F", 5, 50);
        myFinch.setTurn("R", 90, 50);
         myFinch.setMove("F", 5, 50);
        myFinch.setTurn("R", 90, 50);
        myFinch.playNote(60,1);
        myFinch.pause(1);
        myFinch.playNote(60,1);
        myFinch.pause(1);
         myFinch.playNote(60,1);
        myFinch.pause(1);
        myFinch.playNote(59,1);
        myFinch.pause(1);
        myFinch.playNote(57,1);
        myFinch.pause(1);
        myFinch.playNote(59,1);
        myFinch.pause(1);
         myFinch.playNote(60,1);
        myFinch.pause(1);
         myFinch.playNote(62,1);
        myFinch.pause(1);
         myFinch.playNote(64,1);
        myFinch.pause(1);
         myFinch.playNote(64,1);
        myFinch.pause(1);
         myFinch.playNote(64,1);
        myFinch.pause(1);

        for (int i = 0; i < 10; i++) {
            myFinch.setBeak(100, 100, 100);
            myFinch.pause(1);
            myFinch.setBeak(0, 0, 0);
            myFinch.pause(1);
        }

        myFinch.stopAll();
        myFinch.disconnect();
    }
}